// Login

import React from 'react'

export default function Login() {
  return (
    <div className='login'>
      <div className="container">
        <div className="row align-self-center">
          <div className="col-lg-6 align-self-center">
            <h1>The best offer<br></br><span>for your business</span></h1>
            </div>
          <div className="col-lg-6 align-self-center">
          <form>
  <div className="mb-3">
    <label className="form-label">Username</label>
    <input type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"/>
  
  </div>
  <div className="mb-3">
    <label className="form-label">Password</label>
    <input type="password" className="form-control" id="exampleInputPassword1"/>
  </div>

  <button type="submit" className="btn btn-primary">Sign In</button>

  <div className="text-center"><p>or sign up with:</p>
  <button type="button" className="btn btn-link btn-floating mx-1"><i className="fab fa-facebook-f"></i></button>
  <button type="button" className="btn btn-link btn-floating mx-1"><i className="fab fa-google"></i></button>
  <button type="button" className="btn btn-link btn-floating mx-1"><i className="fab fa-twitter"></i></button>
  <button type="button" className="btn btn-link btn-floating mx-1"><i className="fab fa-github"></i></button>
  </div>
</form>
          </div>
        </div>
      </div>
    </div>
  )
}
